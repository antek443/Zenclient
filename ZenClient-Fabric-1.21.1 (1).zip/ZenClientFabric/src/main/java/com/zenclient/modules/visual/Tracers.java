package com.zenclient.modules.visual;
import com.zenclient.modules.Module;
public class Tracers extends Module {
    public Tracers() { super("Tracers", "Tracers module", Category.VISUAL); }
}
