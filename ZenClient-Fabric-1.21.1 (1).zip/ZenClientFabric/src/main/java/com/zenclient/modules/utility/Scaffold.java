package com.zenclient.modules.utility;
import com.zenclient.modules.Module;
public class Scaffold extends Module {
    public Scaffold() { super("Scaffold", "Scaffold module", Category.UTILITY); }
}
