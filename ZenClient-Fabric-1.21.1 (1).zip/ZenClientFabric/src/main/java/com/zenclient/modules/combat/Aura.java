package com.zenclient.modules.combat;

import com.zenclient.modules.Module;
import com.zenclient.modules.settings.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.*;

/**
 * Aura (KillAura) - przepisana z better.tree na Zen Client 1.21.1 Fabric.
 *
 * Tryby rotacji (Mode):
 *   Interact    - minimalne obroty, tylko przy ataku
 *   Track       - płynne śledzenie celu
 *   HVH         - agresywne obroty do HvH
 *   SpookyTime  - obroty z regulowaną prędkością yaw/pitch
 *   HolyWorld   - tryb legit z powolnymi obrotami
 *
 * Sort: LowestDistance, HighestDistance, LowestHealth, HighestHealth,
 *       LowestDurability, HighestDurability, FOV
 *
 * Switch: Normal, None, Silent
 * MoveFix: Off, Focused, Free
 * WallsBypass: Off, V1, V2
 * AttackHand: MainHand, OffHand, None
 * AccelerateOnHit: Off, Yaw, Pitch, Both
 * RayTrace: OFF, OnlyTarget, AllEntities
 */
public class Aura extends Module {

    // =========================================================
    //  Enums
    // =========================================================
    public enum Mode            { Interact, Track, HVH, SpookyTime, HolyWorld }
    public enum Sort            { LowestDistance, HighestDistance, LowestHealth, HighestHealth,
                                  LowestDurability, HighestDurability, FOV }
    public enum Switch          { Normal, None, Silent }
    public enum MoveFix         { Off, Focused, Free }
    public enum WallsBypass     { Off, V1, V2 }
    public enum AttackHand      { MainHand, OffHand, None }
    public enum AccelerateOnHit { Off, Yaw, Pitch, Both }
    public enum RayTrace        { OFF, OnlyTarget, AllEntities }
    public enum ESP             { Off, Veltragossa, NurikZapen, CelkaPasta, ThV2,
                                  renderAlt1, renderAlt2, renderAlt3 }

    // =========================================================
    //  Settings — Ranges
    // =========================================================
    public final Setting<Float>  attackRange    = new Setting<>("AttackRange",   4.0f,  "Zasięg ataku");
    public final Setting<Float>  moveRange      = new Setting<>("MoveRange",     5.0f,  "Zasięg ruchu");
    public final Setting<Float>  wallRange      = new Setting<>("WallRange",     2.0f,  "Zasięg przez ściany");
    public final Setting<Float>  aimRange       = new Setting<>("AimRange",      5.0f,  "Zasięg naprowadzania");
    public final Setting<Integer> fov           = new Setting<>("FOV",           360,   "Kąt FOV (stopnie)");

    // --- Rotations ---
    public final Setting<Mode>   rotationMode   = new Setting<>("RotationMode",  Mode.Track,  "Tryb rotacji");
    public final Setting<Float>  spookyYawSpeed = new Setting<>("YawSpeed",      8.0f,  "Prędkość yaw (SpookyTime)");
    public final Setting<Float>  spookyPitchSpeed = new Setting<>("PitchSpeed",  6.0f,  "Prędkość pitch (SpookyTime)");
    public final Setting<Boolean> spookyAccelOnAttack = new Setting<>("AccelOnAttack", true, "Przyspieszaj przy ataku");
    public final Setting<Integer> minYawStep    = new Setting<>("MinYawStep",    3,     "Min krok yaw");
    public final Setting<Integer> maxYawStep    = new Setting<>("MaxYawStep",    8,     "Max krok yaw");
    public final Setting<Float>  aimedPitchStep = new Setting<>("AimedPitchStep",3.0f, "Krok pitch gdy wycelowany");
    public final Setting<Float>  maxPitchStep   = new Setting<>("MaxPitchStep",  5.0f, "Max krok pitch");
    public final Setting<Float>  pitchAccelerate= new Setting<>("PitchAccel",   1.2f,  "Akceleracja pitch");
    public final Setting<Boolean> showRotation  = new Setting<>("ShowRotation",  false, "Pokaż rotacje po stronie klienta");
    public final Setting<Boolean> clientLook    = new Setting<>("ClientLook",    false, "Użyj rotacji klienta");
    public final Setting<Integer> interactTicks = new Setting<>("InteractTicks", 1,    "Ilość ticków Interact mode");

    // --- Attack timing ---
    public final Setting<Boolean> oldDelay      = new Setting<>("OldDelay",     false,  "Stary delay (CPS-based)");
    public final Setting<Integer> minCPS        = new Setting<>("MinCPS",       10,     "Min CPS");
    public final Setting<Integer> maxCPS        = new Setting<>("MaxCPS",       15,     "Max CPS");
    public final Setting<Float>  attackCooldown = new Setting<>("Cooldown",     0.9f,   "Minimalny cooldown ataku (0-1)");
    public final Setting<Float>  attackBaseTime = new Setting<>("BaseTime",     0.5f,   "Bazowy czas ataku");
    public final Setting<Integer> attackTickLimit = new Setting<>("TickLimit",  20,     "Max ticki bez ataku");
    public final Setting<Boolean> randomHitDelay= new Setting<>("RandomDelay",  true,   "Losowe opóźnienie uderzenia");

    // --- Criticals ---
    public final Setting<Boolean> smartCrit     = new Setting<>("SmartCrit",    true,   "SmartCrit (skacz do krytu)");
    public final Setting<Boolean> onlySpace     = new Setting<>("OnlySpace",    false,  "Kryty tylko ze spacji");
    public final Setting<Boolean> autoJump      = new Setting<>("AutoJump",     true,   "AutoJump dla krytu");
    public final Setting<Float>  critFallDistance = new Setting<>("CritFall",   0.1f,   "Minimalna wysokość upadku dla krytu");

    // --- Combat options ---
    public final Setting<Boolean> shieldBreaker = new Setting<>("ShieldBreaker",true,   "Łam tarcze (toporem)");
    public final Setting<Boolean> pauseWhileEating = new Setting<>("PauseEating",true,  "Pauzuj podczas jedzenia");
    public final Setting<Boolean> tpsSync       = new Setting<>("TPSSync",      false,  "Synchronizuj z TPS serwera");
    public final Setting<Boolean> onlyWeapon    = new Setting<>("OnlyWeapon",   true,   "Tylko z bronią w ręku");
    public final Setting<Switch>  switchMode    = new Setting<>("Switch",       Switch.None,   "Tryb zmiany broni");
    public final Setting<MoveFix> moveFix       = new Setting<>("MoveFix",      MoveFix.Free,  "MoveFix");
    public final Setting<WallsBypass> wallsBypass = new Setting<>("WallsBypass",WallsBypass.Off,"Bypass ścian");
    public final Setting<RayTrace>  rayTrace    = new Setting<>("RayTrace",     RayTrace.OFF,  "RayTrace");
    public final Setting<Boolean> grimRayTrace  = new Setting<>("GrimRayTrace", false,  "Grim AntiCheat RayTrace fix");
    public final Setting<AttackHand> attackHand = new Setting<>("AttackHand",   AttackHand.MainHand, "Ręka do ataku");
    public final Setting<AccelerateOnHit> accelerateOnHit = new Setting<>("AccelerateOnHit", AccelerateOnHit.Off, "Przyspieszaj rotację przy trafieniu");
    public final Setting<Boolean> unpressShield = new Setting<>("UnpressShield",false,  "Zdejmij tarczę przed atakiem");
    public final Setting<Boolean> dropSprint    = new Setting<>("DropSprint",   true,   "Zatrzymaj sprint przed atakiem");
    public final Setting<Boolean> returnSprint  = new Setting<>("ReturnSprint", true,   "Wróć do sprintu po ataku");
    public final Setting<Boolean> pullDown      = new Setting<>("PullDown",     false,  "Przyciągnij cel w dół");
    public final Setting<Boolean> onlyJumpBoost = new Setting<>("OnlyJumpBoost",false,  "Tylko z Jump Boost");
    public final Setting<Float>  pullValue      = new Setting<>("PullValue",    0.1f,   "Siła przyciągania w dół");
    public final Setting<Boolean> deathDisable  = new Setting<>("DeathDisable", true,   "Wyłącz po śmierci");
    public final Setting<Boolean> tpDisable     = new Setting<>("TPDisable",    true,   "Wyłącz po teleporcie");
    public final Setting<Boolean> pauseInInventory = new Setting<>("PauseInventory", true, "Pauzuj w ekwipunku");
    public final Setting<Boolean> pauseBaritone = new Setting<>("PauseBaritone",false,  "Pauzuj z Baritone");
    public final Setting<Boolean> lockTarget    = new Setting<>("LockTarget",   false,  "Zablokuj cel");
    public final Setting<Sort>    sort          = new Setting<>("Sort",         Sort.LowestDistance, "Sortowanie celu");
    public final Setting<Boolean> ignoreColorTeam = new Setting<>("IgnoreColorTeam", false, "Ignoruj color-team");

    // --- Elytra ---
    public final Setting<Boolean> elytra        = new Setting<>("Elytra",       false,  "Atakuj podczas lotu elytrą");
    public final Setting<Float>  elytraAttackRange = new Setting<>("ElytraRange",6.0f,  "Zasięg podczas elytra");

    // --- Targets ---
    public final Setting<Boolean> Players       = new Setting<>("Players",      true,   "Atakuj graczy");
    public final Setting<Boolean> Mobs          = new Setting<>("Mobs",         false,  "Atakuj moby");
    public final Setting<Boolean> Animals       = new Setting<>("Animals",      false,  "Atakuj zwierzęta");
    public final Setting<Boolean> Villagers     = new Setting<>("Villagers",    false,  "Atakuj wieśniaków");
    public final Setting<Boolean> Slimes        = new Setting<>("Slimes",       false,  "Atakuj szlamy");
    public final Setting<Boolean> hostiles      = new Setting<>("Hostiles",     false,  "Tylko wrogie moby");
    public final Setting<Boolean> onlyAngry     = new Setting<>("OnlyAngry",    false,  "Tylko rozgniewane");
    public final Setting<Boolean> Projectiles   = new Setting<>("Projectiles",  false,  "Atakuj pociski");
    public final Setting<Boolean> ignoreInvisible = new Setting<>("IgnoreInvis",false,  "Ignoruj niewidocznych");
    public final Setting<Boolean> ignoreNamed   = new Setting<>("IgnoreNamed",  false,  "Ignoruj nazwanych");
    public final Setting<Boolean> ignoreTeam    = new Setting<>("IgnoreTeam",   true,   "Ignoruj drużynę");
    public final Setting<Boolean> ignoreCreative= new Setting<>("IgnoreCreative",true,  "Ignoruj tryb kreatywny");
    public final Setting<Boolean> ignoreNaked   = new Setting<>("IgnoreNaked",  false,  "Ignoruj bez zbroi");
    public final Setting<Boolean> ignoreShield  = new Setting<>("IgnoreShield", false,  "Ignoruj z tarczą");

    // --- ESP ---
    public final Setting<ESP>     esp           = new Setting<>("ESP",          ESP.Off, "Tryb ESP");
    public final Setting<Integer> espLength     = new Setting<>("ESPLength",    30,     "Długość ESP");
    public final Setting<Integer> espFactor     = new Setting<>("ESPFactor",    3,      "Czynnik ESP");
    public final Setting<Float>   espScale      = new Setting<>("ESPScale",     1.0f,   "Skala ESP");
    public final Setting<Float>   espShaking    = new Setting<>("ESPShaking",   0.5f,   "Trzęsienie ESP");
    public final Setting<Float>   espAmplitude  = new Setting<>("ESPAmplitude", 1.0f,   "Amplituda ESP");
    public final Setting<Boolean> redOnImpact   = new Setting<>("RedOnImpact",  true,   "Czerwony przy trafieniu");
    public final Setting<Float>   hitColorDuration = new Setting<>("HitColorDuration", 0.3f, "Czas koloru przy trafieniu");

    // =========================================================
    //  State
    // =========================================================
    public static Entity target       = null;
    public float   rotationYaw        = 0f;
    public float   rotationPitch      = 0f;
    public float   pitchAcceleration  = 0f;

    private boolean critState         = false;
    private int     hitTicks          = 0;
    private boolean hitColorActive    = false;
    private long    lastHitTime       = 0;

    private float   lastYawSpeed      = 0f;
    private float   lastPitchSpeed    = 0f;

    private final Map<Integer, Long> hitMap       = new HashMap<>();
    private final Random             rng          = new Random();
    private long                     lastAttackMs = 0;

    // =========================================================
    //  Lifecycle
    // =========================================================
    public Aura() {
        super("Aura", "Zaawansowana KillAura z pełnymi ustawieniami", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        target = null;
        critState = false;
        hitTicks = 0;
    }

    @Override
    public void onDisable() {
        target = null;
        if (mc.player != null) {
            mc.player.setSprinting(false);
        }
    }

    // =========================================================
    //  Main tick
    // =========================================================
    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (pauseInInventory.getValue() && mc.currentScreen != null) return;
        if (pauseWhileEating.getValue() && mc.player.isUsingItem()) return;

        // Elytra check
        if (mc.player.isFallFlying() && !elytra.getValue()) return;

        // Weapon check
        if (onlyWeapon.getValue() && !haveWeapon()) return;

        // Update target
        updateTarget();
        if (target == null) return;

        // Calc rotations
        calcRotations();

        // Attack logic
        auraLogic();
    }

    // =========================================================
    //  Target
    // =========================================================
    private void updateTarget() {
        if (lockTarget.getValue() && target != null && isInRange(target)) return;

        List<LivingEntity> candidates = new ArrayList<>();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living)) continue;
            if (!living.isAlive()) continue;
            if (living == mc.player) continue;
            if (skipEntity(living)) continue;
            if (!isInRange(living)) continue;
            if (!checkFOV(living)) continue;
            candidates.add(living);
        }

        if (candidates.isEmpty()) { target = null; return; }

        candidates.sort(getComparator());
        target = candidates.get(0);
    }

    private boolean skipEntity(Entity e) {
        if (ignoreInvisible.getValue() && e.isInvisible()) return true;
        if (ignoreNamed.getValue() && e.hasCustomName()) return true;
        if (ignoreCreative.getValue() && e instanceof PlayerEntity p && p.isCreative()) return true;
        if (ignoreTeam.getValue() && mc.player.isTeammate(e)) return true;

        if (e instanceof PlayerEntity) return !Players.getValue();
        if (e instanceof SlimeEntity)  return !Slimes.getValue();
        if (e instanceof VillagerEntity) return !Villagers.getValue();
        if (e instanceof AnimalEntity) return !Animals.getValue();
        if (e instanceof HostileEntity) return !Mobs.getValue();
        if (e instanceof ProjectileEntity) return !Projectiles.getValue();

        return false;
    }

    public boolean isInRange(Entity e) {
        if (mc.player == null) return false;
        float range = (mc.player.isFallFlying() && elytra.getValue())
            ? elytraAttackRange.getValue()
            : attackRange.getValue();

        // Wall check
        if (!canSeeEntity(e)) {
            if (wallsBypass.getValue() == WallsBypass.Off) return false;
            range = wallRange.getValue();
        }

        return mc.player.distanceTo(e) <= range;
    }

    private boolean canSeeEntity(Entity e) {
        if (rayTrace.getValue() == RayTrace.OFF) return true;
        if (mc.world == null || mc.player == null) return false;

        Vec3d eyes = mc.player.getEyePos();
        Vec3d target = e.getEyePos();

        HitResult result = mc.world.raycast(new RaycastContext(
            eyes, target,
            RaycastContext.ShapeType.COLLIDER,
            RaycastContext.FluidHandling.NONE,
            mc.player
        ));

        return result.getType() == HitResult.Type.MISS;
    }

    private boolean checkFOV(Entity e) {
        if (fov.getValue() >= 360) return true;
        if (mc.player == null) return false;

        Vec3d diff = e.getPos().subtract(mc.player.getPos()).normalize();
        float playerYaw = mc.player.getYaw();
        double angle = Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90;
        double delta = Math.abs(MathHelper.wrapDegrees((float)(angle - playerYaw)));
        return delta <= fov.getValue() / 2.0;
    }

    private Comparator<LivingEntity> getComparator() {
        return switch (sort.getValue()) {
            case LowestDistance  -> Comparator.comparingDouble(e -> mc.player.distanceTo(e));
            case HighestDistance -> Comparator.comparingDouble((LivingEntity e) -> mc.player.distanceTo(e)).reversed();
            case LowestHealth    -> Comparator.comparingDouble(e -> e.getHealth());
            case HighestHealth   -> Comparator.comparingDouble((LivingEntity e) -> e.getHealth()).reversed();
            case LowestDurability -> Comparator.comparingInt(e -> getArmorDurability(e));
            case HighestDurability -> Comparator.comparingInt((LivingEntity e) -> getArmorDurability(e)).reversed();
            case FOV             -> Comparator.comparingDouble(e -> getFOVAngle(e));
        };
    }

    private int getArmorDurability(LivingEntity e) {
        return e.getArmorItems() == null ? 0 :
            (int) ((Iterable<net.minecraft.item.ItemStack>) e.getArmorItems()).spliterator()
                .estimateSize();
    }

    private double getFOVAngle(Entity e) {
        if (mc.player == null) return 0;
        Vec3d diff = e.getPos().subtract(mc.player.getPos()).normalize();
        float yaw = mc.player.getYaw();
        return Math.abs(MathHelper.wrapDegrees(
            (float)(Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90) - yaw));
    }

    // =========================================================
    //  Rotations
    // =========================================================
    private void calcRotations() {
        if (target == null || mc.player == null) return;

        Vec3d targetPos = getLegitLook(target);
        Vec3d diff = targetPos.subtract(mc.player.getEyePos());

        double dist = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float targetYaw   = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, dist));

        switch (rotationMode.getValue()) {
            case Track, HVH -> {
                rotationYaw   = targetYaw;
                rotationPitch = targetPitch;
            }
            case SpookyTime -> {
                float dyaw   = MathHelper.wrapDegrees(targetYaw - rotationYaw);
                float dpitch = MathHelper.wrapDegrees(targetPitch - rotationPitch);
                float ys = spookyYawSpeed.getValue();
                float ps = spookyPitchSpeed.getValue();
                rotationYaw   += MathHelper.clamp(dyaw,   -ys, ys);
                rotationPitch += MathHelper.clamp(dpitch, -ps, ps);
            }
            case HolyWorld -> {
                int step = minYawStep.getValue() + rng.nextInt(Math.max(1, maxYawStep.getValue() - minYawStep.getValue()));
                float dyaw   = MathHelper.wrapDegrees(targetYaw - rotationYaw);
                float dpitch = MathHelper.wrapDegrees(targetPitch - rotationPitch);
                rotationYaw   += MathHelper.clamp(dyaw,   -step, step);
                rotationPitch += MathHelper.clamp(dpitch, -maxPitchStep.getValue(), maxPitchStep.getValue());
            }
            case Interact -> {
                rotationYaw   = targetYaw;
                rotationPitch = targetPitch;
            }
        }

        rotationPitch = MathHelper.clamp(rotationPitch, -90f, 90f);

        if (showRotation.getValue() || clientLook.getValue()) {
            mc.player.setYaw(rotationYaw);
            mc.player.setPitch(rotationPitch);
        }
    }

    public Vec3d getLegitLook(Entity e) {
        Box box = e.getBoundingBox();
        double x = (box.minX + box.maxX) / 2;
        double y = box.minY + (box.maxY - box.minY) * 0.8;
        double z = (box.minZ + box.maxZ) / 2;
        return new Vec3d(x, y, z);
    }

    // =========================================================
    //  Attack
    // =========================================================
    private void auraLogic() {
        if (target == null || mc.player == null) return;

        // Cooldown check
        if (!canAttack()) return;

        // SmartCrit
        if (smartCrit.getValue()) {
            handleCrit();
        }

        // Shield breaker
        if (shieldBreaker.getValue() && target instanceof PlayerEntity tp && tp.isBlocking()) {
            switchToAxe();
        }

        // Drop sprint before attack
        if (dropSprint.getValue()) mc.player.setSprinting(false);

        // Attack
        attack();

        // Return sprint
        if (returnSprint.getValue()) mc.player.setSprinting(true);

        lastAttackMs = System.currentTimeMillis();
    }

    private boolean canAttack() {
        if (mc.player == null) return false;

        if (oldDelay.getValue()) {
            // CPS-based delay
            int cps = minCPS.getValue() + rng.nextInt(Math.max(1, maxCPS.getValue() - minCPS.getValue() + 1));
            long delayMs = 1000L / cps;
            if (randomHitDelay.getValue()) delayMs += rng.nextInt(50);
            return System.currentTimeMillis() - lastAttackMs >= delayMs;
        } else {
            // Cooldown-based
            return mc.player.getAttackCooldownProgress(0f) >= attackCooldown.getValue();
        }
    }

    private void handleCrit() {
        if (mc.player == null) return;
        if (mc.player.isOnGround() && autoJump.getValue()) {
            mc.player.jump();
        }
        // Simulate small fall for crit
        if (!mc.player.isOnGround() && mc.player.fallDistance >= critFallDistance.getValue()) {
            critState = true;
        }
    }

    public void attack() {
        if (target == null || mc.player == null || mc.interactionManager == null) return;

        Hand hand = switch (attackHand.getValue()) {
            case MainHand -> Hand.MAIN_HAND;
            case OffHand  -> Hand.OFF_HAND;
            case None     -> null;
        };

        if (hand == null) return;

        mc.player.swingHand(hand);
        mc.interactionManager.attackEntity(mc.player, target);

        // Pull down
        if (pullDown.getValue()) {
            target.setVelocity(target.getVelocity().add(0, -pullValue.getValue(), 0));
        }

        hitTicks = 0;
        lastHitTime = System.currentTimeMillis();
        hitColorActive = true;

        // AccelerateOnHit
        if (accelerateOnHit.getValue() != AccelerateOnHit.Off) {
            switch (accelerateOnHit.getValue()) {
                case Yaw   -> lastYawSpeed   += 2f;
                case Pitch -> lastPitchSpeed += 2f;
                case Both  -> { lastYawSpeed += 2f; lastPitchSpeed += 2f; }
            }
        }
    }

    // =========================================================
    //  Helpers
    // =========================================================
    private boolean haveWeapon() {
        if (mc.player == null) return false;
        var item = mc.player.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem;
    }

    private void switchToAxe() {
        if (mc.player == null) return;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() instanceof AxeItem) {
                mc.player.getInventory().selectedSlot = i;
                return;
            }
        }
    }

    public boolean isEntityHit(Entity e) {
        return e == target && hitColorActive
            && System.currentTimeMillis() - lastHitTime < (hitColorDuration.getValue() * 1000);
    }
}
