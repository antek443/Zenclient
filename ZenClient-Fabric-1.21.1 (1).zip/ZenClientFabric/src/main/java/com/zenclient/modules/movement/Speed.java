package com.zenclient.modules.movement;
import com.zenclient.modules.Module;
public class Speed extends Module {
    public Speed() { super("Speed", "Speed module", Category.MOVEMENT); }
}
