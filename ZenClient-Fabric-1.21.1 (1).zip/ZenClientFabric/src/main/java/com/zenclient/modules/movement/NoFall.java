package com.zenclient.modules.movement;
import com.zenclient.modules.Module;
public class NoFall extends Module {
    public NoFall() { super("NoFall", "NoFall module", Category.MOVEMENT); }
}
