package com.zenclient.modules.combat;
import com.zenclient.modules.Module;
public class KillAura extends Module {
    public KillAura() { super("KillAura", "KillAura module", Category.COMBAT); }
}
