package com.zenclient.modules.movement;
import com.zenclient.modules.Module;
public class Fly extends Module {
    public Fly() { super("Fly", "Fly module", Category.MOVEMENT); }
}
