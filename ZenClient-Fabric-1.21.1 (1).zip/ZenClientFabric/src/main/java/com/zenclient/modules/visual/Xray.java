package com.zenclient.modules.visual;
import com.zenclient.modules.Module;
public class Xray extends Module {
    public Xray() { super("Xray", "Xray module", Category.VISUAL); }
}
