package com.zenclient.modules.movement;
import com.zenclient.modules.Module;
public class Step extends Module {
    public Step() { super("Step", "Step module", Category.MOVEMENT); }
}
