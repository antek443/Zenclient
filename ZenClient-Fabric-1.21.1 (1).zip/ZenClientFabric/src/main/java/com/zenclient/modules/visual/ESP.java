package com.zenclient.modules.visual;
import com.zenclient.modules.Module;
public class ESP extends Module {
    public ESP() { super("ESP", "ESP module", Category.VISUAL); }
}
