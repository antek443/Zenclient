package com.zenclient.modules.utility;
import com.zenclient.modules.Module;
public class AutoTotem extends Module {
    public AutoTotem() { super("AutoTotem", "AutoTotem module", Category.UTILITY); }
}
