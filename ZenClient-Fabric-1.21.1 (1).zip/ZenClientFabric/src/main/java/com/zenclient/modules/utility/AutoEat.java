package com.zenclient.modules.utility;
import com.zenclient.modules.Module;
public class AutoEat extends Module {
    public AutoEat() { super("AutoEat", "AutoEat module", Category.UTILITY); }
}
