package com.zenclient.modules.visual;
import com.zenclient.modules.Module;
public class NoWeather extends Module {
    public NoWeather() { super("NoWeather", "NoWeather module", Category.VISUAL); }
}
