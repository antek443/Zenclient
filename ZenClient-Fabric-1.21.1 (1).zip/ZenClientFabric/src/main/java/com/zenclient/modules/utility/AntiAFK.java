package com.zenclient.modules.utility;
import com.zenclient.modules.Module;
public class AntiAFK extends Module {
    public AntiAFK() { super("AntiAFK", "AntiAFK module", Category.UTILITY); }
}
