package com.zenclient.modules.visual;
import com.zenclient.modules.Module;
public class ChestESP extends Module {
    public ChestESP() { super("ChestESP", "ChestESP module", Category.VISUAL); }
}
