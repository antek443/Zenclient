package com.zenclient.modules.utility;
import com.zenclient.modules.Module;
public class PacketFly extends Module {
    public PacketFly() { super("PacketFly", "PacketFly module", Category.UTILITY); }
}
