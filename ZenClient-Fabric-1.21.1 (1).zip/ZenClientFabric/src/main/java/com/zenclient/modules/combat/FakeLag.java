package com.zenclient.modules.combat;

import com.zenclient.modules.Module;
import com.zenclient.modules.settings.Setting;
import net.minecraft.network.packet.Packet;

import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * FakeLag - opóźnia wysyłanie paczek do serwera, symulując lag.
 * Przepisany z better.tree na potrzeby Zen Client 1.21.1 Fabric.
 *
 * Tryby:
 *  OLD - stały czas lagowania (pulseLength ms), potem pauza (pulseDelay ms)
 *  NEW - losowy delay między lagDelayMin a lagDelayMax ms
 *
 * RenderMode:
 *  Circle - rysuje okrąg w miejscu "zamrożonej" pozycji
 *  Box    - rysuje box
 *  All    - oba
 */
public class FakeLag extends Module {

    public enum Mode { OLD, NEW }
    public enum RenderMode { Circle, Box, All }

    // --- Settings ---
    public final Setting<Mode>       mode           = new Setting<>("Mode",         Mode.OLD,  "Tryb lagowania");
    public final Setting<Integer>    pulseLength    = new Setting<>("PulseLength",  1000,      "Czas lagowania w ms (tryb OLD)");
    public final Setting<Integer>    pulseDelay     = new Setting<>("PulseDelay",   500,       "Przerwa między pulsami ms (tryb OLD)");
    public final Setting<Boolean>    render         = new Setting<>("Render",       true,      "Renderuj pozycję lagowania");
    public final Setting<RenderMode> renderMode     = new Setting<>("RenderMode",   RenderMode.Box, "Tryb renderowania");
    public final Setting<Integer>    lagDelayMin    = new Setting<>("LagDelayMin",  200,       "Min losowy delay ms (tryb NEW)");
    public final Setting<Integer>    lagDelayMax    = new Setting<>("LagDelayMax",  2000,      "Max losowy delay ms (tryb NEW)");
    public final Setting<Boolean>    cancelOnElytra = new Setting<>("CancelElytra", true,      "Wyłącz podczas lotu elytrą");

    // --- State ---
    private final Queue<Packet<?>> storedPackets = new ArrayDeque<>();
    private final AtomicBoolean    sending       = new AtomicBoolean(false);
    private final Random           rng           = new Random();

    private boolean isLagging       = false;
    private long    lagStartMs       = 0;
    private long    pauseStartMs     = 0;
    private int     currentDelay     = 0;
    private long    displayedLagMs   = 0;

    // Pozycja "zamrożona" (do renderowania)
    private double frozenX, frozenY, frozenZ;

    public FakeLag() {
        super("FakeLag", "Symuluje lag - opóźnia paczki do serwera", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        if (mc.player == null) return;
        frozenX = mc.player.getX();
        frozenY = mc.player.getY();
        frozenZ = mc.player.getZ();
        startLag();
    }

    @Override
    public void onDisable() {
        flushPackets();
        isLagging = false;
        storedPackets.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.networkHandler == null) return;

        // Anuluj jeśli leci elytrą
        if (cancelOnElytra.getValue() && mc.player.isFallFlying()) {
            flushPackets();
            return;
        }

        long now = System.currentTimeMillis();

        switch (mode.getValue()) {
            case OLD -> tickOldMode(now);
            case NEW -> tickNewMode(now);
        }

        displayedLagMs = isLagging ? (now - lagStartMs) : 0;
    }

    private void tickOldMode(long now) {
        if (isLagging) {
            if (now - lagStartMs >= pulseLength.getValue()) {
                // Koniec pulsowania - wyślij paczki
                flushPackets();
                isLagging = false;
                pauseStartMs = now;
            }
        } else {
            if (now - pauseStartMs >= pulseDelay.getValue()) {
                startLag();
            }
        }
    }

    private void tickNewMode(long now) {
        if (isLagging) {
            if (now - lagStartMs >= currentDelay) {
                flushPackets();
                isLagging = false;
                // Losowy nowy delay
                int min = lagDelayMin.getValue();
                int max = Math.max(min + 1, lagDelayMax.getValue());
                currentDelay = min + rng.nextInt(max - min);
                pauseStartMs = now;
            }
        } else {
            if (now - pauseStartMs >= 50) { // krótka przerwa 50ms
                startLag();
            }
        }
    }

    private void startLag() {
        isLagging = true;
        lagStartMs = System.currentTimeMillis();
        if (mc.player != null) {
            frozenX = mc.player.getX();
            frozenY = mc.player.getY();
            frozenZ = mc.player.getZ();
        }
    }

    /**
     * Wywoływane z Mixina przy wysyłaniu paczki.
     * Zwraca true jeśli paczka powinna być zablokowana (dodana do kolejki).
     */
    public boolean onPacketSend(Packet<?> packet) {
        if (!isEnabled() || !isLagging || sending.get()) return false;
        storedPackets.add(packet);
        return true; // zablokuj wysyłanie
    }

    private void flushPackets() {
        if (mc.getNetworkHandler() == null) {
            storedPackets.clear();
            return;
        }
        sending.set(true);
        while (!storedPackets.isEmpty()) {
            Packet<?> pkt = storedPackets.poll();
            if (pkt != null) mc.getNetworkHandler().sendPacket(pkt);
        }
        sending.set(false);
    }

    public boolean isLaggingNow()    { return isLagging; }
    public long    getCurrentLagMs() { return displayedLagMs; }
    public double  getFrozenX()      { return frozenX; }
    public double  getFrozenY()      { return frozenY; }
    public double  getFrozenZ()      { return frozenZ; }
}
