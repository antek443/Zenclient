package com.zenclient.modules;

import com.zenclient.modules.combat.*;
import com.zenclient.modules.movement.*;
import com.zenclient.modules.visual.*;
import com.zenclient.modules.utility.*;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public void initModules() {
        // COMBAT
        register(new Aura());
        register(new KillAura());
        register(new Criticals());
        register(new AntiKnockback());
        register(new Reach());
        register(new AutoClicker());
        register(new HitboxExpand());
        register(new Velocity());
        register(new FakeLag());
        register(new AutoWeb());
        register(new AutoTrap());

        // MOVEMENT
        register(new Sprint());
        register(new Fly());
        register(new Speed());
        register(new HighJump());
        register(new NoFall());
        register(new Sneak());
        register(new BunnyHop());
        register(new Step());

        // VISUAL
        register(new FullBright());
        register(new ESP());
        register(new Tracers());
        register(new ChestESP());
        register(new Xray());
        register(new NoWeather());
        register(new Zoom());
        register(new FreeCam());
        register(new HUD());
        register(new ClearChat());

        // UTILITY
        register(new AutoTotem());
        register(new Scaffold());
        register(new FastPlace());
        register(new NoRotate());
        register(new AntiAFK());
        register(new AutoEat());
        register(new Namespoof());
        register(new PacketFly());
        register(new Disabler());
        register(new Timer());
    }

    public void register(Module m) { modules.add(m); }

    public void tickModules() {
        for (Module m : modules) if (m.isEnabled()) m.onTick();
    }

    public void renderHUD(DrawContext ctx) {
        int y = 2;
        for (Module m : getEnabledModules()) { m.onRenderHUD(ctx, 2, y); y += 10; }
    }

    public List<Module> getModules() { return modules; }
    public List<Module> getByCategory(Module.Category cat) {
        return modules.stream().filter(m -> m.getCategory() == cat).collect(Collectors.toList());
    }
    public List<Module> getEnabledModules() {
        return modules.stream().filter(Module::isEnabled).collect(Collectors.toList());
    }
    public Module getByName(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }
}
