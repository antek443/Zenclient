package com.zenclient.modules.utility;
import com.zenclient.modules.Module;
public class FastPlace extends Module {
    public FastPlace() { super("FastPlace", "FastPlace module", Category.UTILITY); }
}
