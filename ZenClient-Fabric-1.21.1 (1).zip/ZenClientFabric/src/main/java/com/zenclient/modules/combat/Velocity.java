package com.zenclient.modules.combat;
import com.zenclient.modules.Module;
public class Velocity extends Module {
    public Velocity() { super("Velocity", "Velocity module", Category.COMBAT); }
}
