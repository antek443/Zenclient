package com.zenclient.modules.combat;

import com.zenclient.modules.Module;
import com.zenclient.modules.settings.Setting;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * AutoWeb - automatycznie stawia pajęczyny wokół celu.
 * Przepisany z better.tree na potrzeby Zen Client 1.21.1 Fabric.
 *
 * PlaceTiming:
 *   Default - stawia co placeDelay ticków
 *   Vanilla - stawia max blocksPerTick na tick
 *
 * RenderMode:
 *   Fade     - renderuje z zanikaniem
 *   Decrease - renderuje ze zmniejszaniem
 */
public class AutoWeb extends Module {

    public enum PlaceTiming { Default, Vanilla }
    public enum RenderMode  { Fade, Decrease }

    // --- Settings ---
    public final Setting<Integer>     range          = new Setting<>("Range",          4,               "Zasięg do gracza");
    public final Setting<Integer>     placeWallRange = new Setting<>("WallRange",      3,               "Zasięg przez ściany");
    public final Setting<PlaceTiming> placeTiming    = new Setting<>("PlaceTiming",    PlaceTiming.Default, "Tryb stawiania");
    public final Setting<Integer>     blocksPerTick  = new Setting<>("BlocksPerTick",  2,               "Bloki na tick (Vanilla)");
    public final Setting<Integer>     placeDelay     = new Setting<>("PlaceDelay",     3,               "Delay między blokami (ticki)");
    public final Setting<Boolean>     head           = new Setting<>("Head",           true,            "Stawiaj na głowie");
    public final Setting<Boolean>     legs           = new Setting<>("Legs",           true,            "Stawiaj na nogach");
    public final Setting<Boolean>     surround       = new Setting<>("Surround",       true,            "Otocz wokół");
    public final Setting<Boolean>     upperSurround  = new Setting<>("UpperSurround",  false,           "Górna warstwa otoczenia");
    public final Setting<RenderMode>  renderMode     = new Setting<>("RenderMode",     RenderMode.Fade, "Tryb renderowania");
    public final Setting<Integer>     effectDuration = new Setting<>("EffectDuration", 500,             "Czas efektu renderowania ms");

    // --- State ---
    private final List<BlockPos>  pendingBlocks = new ArrayList<>();
    private int                   delayCounter  = 0;
    private int                   savedSlot     = -1;

    public AutoWeb() {
        super("AutoWeb", "Automatycznie stawia pajęczyny wokół celu", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        pendingBlocks.clear();
        delayCounter = 0;
    }

    @Override
    public void onDisable() {
        pendingBlocks.clear();
        restoreSlot();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        // Znajdź najbliższy cel
        ClientPlayerEntity target = findTarget();
        if (target == null) return;

        // Znajdź slot z pajęczyną
        int webSlot = findWebSlot();
        if (webSlot == -1) return;

        // Oblicz pozycje do postawienia
        pendingBlocks.clear();
        buildWebPositions(target);

        if (pendingBlocks.isEmpty()) return;

        // Przełącz na pajęczynę
        savedSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = webSlot;

        switch (placeTiming.getValue()) {
            case Default -> placeWithDelay();
            case Vanilla -> placeMultiple();
        }
    }

    private void buildWebPositions(ClientPlayerEntity target) {
        BlockPos tPos = target.getBlockPos();

        if (legs.getValue())  pendingBlocks.add(tPos);
        if (head.getValue())  pendingBlocks.add(tPos.up());

        if (surround.getValue()) {
            for (Direction dir : Direction.Type.HORIZONTAL) {
                BlockPos side = tPos.offset(dir);
                if (isPlaceable(side)) pendingBlocks.add(side);
            }
        }

        if (upperSurround.getValue()) {
            for (Direction dir : Direction.Type.HORIZONTAL) {
                BlockPos side = tPos.up().offset(dir);
                if (isPlaceable(side)) pendingBlocks.add(side);
            }
        }

        // Filtruj tylko puste miejsca w zasięgu
        pendingBlocks.removeIf(pos ->
            !isPlaceable(pos) || mc.player.getPos().distanceTo(Vec3d.ofCenter(pos)) > range.getValue()
        );
    }

    private void placeWithDelay() {
        if (delayCounter > 0) { delayCounter--; return; }
        if (!pendingBlocks.isEmpty()) {
            placeAt(pendingBlocks.get(0));
            delayCounter = placeDelay.getValue();
        }
        restoreSlot();
    }

    private void placeMultiple() {
        int count = 0;
        for (BlockPos pos : pendingBlocks) {
            if (count >= blocksPerTick.getValue()) break;
            placeAt(pos);
            count++;
        }
        restoreSlot();
    }

    private void placeAt(BlockPos pos) {
        if (mc.interactionManager == null || mc.player == null) return;
        // Znajdź sąsiada do kliknięcia
        for (Direction dir : Direction.values()) {
            BlockPos neighbor = pos.offset(dir);
            if (mc.world.getBlockState(neighbor).isSolidBlock(mc.world, neighbor)) {
                BlockHitResult hit = new BlockHitResult(
                    Vec3d.ofCenter(pos), dir.getOpposite(), neighbor, false
                );
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
                return;
            }
        }
    }

    private boolean isPlaceable(BlockPos pos) {
        if (mc.world == null) return false;
        return mc.world.getBlockState(pos).isAir();
    }

    private ClientPlayerEntity findTarget() {
        if (mc.world == null || mc.player == null) return null;
        double r = range.getValue();
        return mc.world.getPlayers().stream()
            .filter(p -> p != mc.player && p.isAlive())
            .filter(p -> p.distanceTo(mc.player) <= r)
            .min((a, b) -> Double.compare(a.distanceTo(mc.player), b.distanceTo(mc.player)))
            .orElse(null);
    }

    private int findWebSlot() {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() == Items.COBWEB) return i;
        }
        return -1;
    }

    private void restoreSlot() {
        if (savedSlot != -1 && mc.player != null) {
            mc.player.getInventory().selectedSlot = savedSlot;
            savedSlot = -1;
        }
    }
}
