package com.zenclient.modules.visual;
import com.zenclient.modules.Module;
public class FreeCam extends Module {
    public FreeCam() { super("FreeCam", "FreeCam module", Category.VISUAL); }
}
