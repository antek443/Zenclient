package com.zenclient.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class Module {

    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled = false;
    private int keybind = -1;

    public enum Category {
        COMBAT("Combat", "\u2694"),
        MOVEMENT("Movement", "\u26A1"),
        VISUAL("Visual", "\u2728"),
        UTILITY("Utility", "\u2699");

        public final String label;
        public final String icon;

        Category(String label, String icon) {
            this.label = label;
            this.icon = icon;
        }
    }

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onRenderHUD(DrawContext context, int x, int y) {}

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) {
        boolean was = this.enabled;
        this.enabled = enabled;
        if (!was && enabled) onEnable();
        else if (was && !enabled) onDisable();
    }
    public int getKeybind() { return keybind; }
    public void setKeybind(int k) { this.keybind = k; }
}
