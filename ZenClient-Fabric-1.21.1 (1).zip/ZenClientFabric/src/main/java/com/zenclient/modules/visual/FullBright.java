package com.zenclient.modules.visual;
import com.zenclient.modules.Module;
public class FullBright extends Module {
    public FullBright() { super("FullBright", "FullBright module", Category.VISUAL); }
}
