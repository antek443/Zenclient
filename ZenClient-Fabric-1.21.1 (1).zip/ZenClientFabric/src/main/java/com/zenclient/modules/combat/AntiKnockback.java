package com.zenclient.modules.combat;
import com.zenclient.modules.Module;
public class AntiKnockback extends Module {
    public AntiKnockback() { super("AntiKnockback", "AntiKnockback module", Category.COMBAT); }
}
