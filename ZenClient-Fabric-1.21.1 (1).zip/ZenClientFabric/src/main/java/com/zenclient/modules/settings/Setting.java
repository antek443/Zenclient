package com.zenclient.modules.settings;

/**
 * Prosta klasa ustawień dla modułów Zen Client.
 * Każde ustawienie ma nazwę, wartość domyślną i opis.
 */
public class Setting<T> {

    private final String name;
    private final String description;
    private T value;
    private final T defaultValue;

    public Setting(String name, T defaultValue, String description) {
        this.name         = name;
        this.defaultValue = defaultValue;
        this.value        = defaultValue;
        this.description  = description;
    }

    public T      getValue()                  { return value; }
    public void   setValue(T value)           { this.value = value; }
    public String getName()                   { return name; }
    public String getDescription()            { return description; }
    public T      getDefaultValue()           { return defaultValue; }
    public void   reset()                     { this.value = defaultValue; }

    @Override
    public String toString() {
        return name + " = " + value;
    }
}
