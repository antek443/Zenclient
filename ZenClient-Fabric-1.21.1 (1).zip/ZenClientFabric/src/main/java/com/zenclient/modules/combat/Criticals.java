package com.zenclient.modules.combat;
import com.zenclient.modules.Module;
public class Criticals extends Module {
    public Criticals() { super("Criticals", "Criticals module", Category.COMBAT); }
}
