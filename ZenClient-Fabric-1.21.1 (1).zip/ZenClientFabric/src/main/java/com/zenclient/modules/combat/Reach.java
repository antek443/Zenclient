package com.zenclient.modules.combat;
import com.zenclient.modules.Module;
public class Reach extends Module {
    public Reach() { super("Reach", "Reach module", Category.COMBAT); }
}
