package com.zenclient.modules.movement;
import com.zenclient.modules.Module;
public class HighJump extends Module {
    public HighJump() { super("HighJump", "HighJump module", Category.MOVEMENT); }
}
