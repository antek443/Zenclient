package com.zenclient.modules.combat;
import com.zenclient.modules.Module;
public class AutoClicker extends Module {
    public AutoClicker() { super("AutoClicker", "AutoClicker module", Category.COMBAT); }
}
