package com.zenclient.modules.utility;
import com.zenclient.modules.Module;
public class NoRotate extends Module {
    public NoRotate() { super("NoRotate", "NoRotate module", Category.UTILITY); }
}
