package com.zenclient.modules.visual;
import com.zenclient.modules.Module;
public class HUD extends Module {
    public HUD() { super("HUD", "HUD module", Category.VISUAL); }
}
