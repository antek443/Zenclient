package com.zenclient.modules.visual;
import com.zenclient.modules.Module;
public class Zoom extends Module {
    public Zoom() { super("Zoom", "Zoom module", Category.VISUAL); }
}
