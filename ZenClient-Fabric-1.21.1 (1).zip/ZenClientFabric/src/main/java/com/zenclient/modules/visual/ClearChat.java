package com.zenclient.modules.visual;
import com.zenclient.modules.Module;
public class ClearChat extends Module {
    public ClearChat() { super("ClearChat", "ClearChat module", Category.VISUAL); }
}
