package com.zenclient.modules.utility;
import com.zenclient.modules.Module;
public class Timer extends Module {
    public Timer() { super("Timer", "Timer module", Category.UTILITY); }
}
