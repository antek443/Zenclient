package com.zenclient.modules.combat;

import com.zenclient.modules.Module;
import com.zenclient.modules.settings.Setting;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.player.PlayerInventory;

import java.util.ArrayList;
import java.util.List;

/**
 * AutoTrap - otacza cel klatką z obsydianu/innych bloków.
 * Przepisany z better.tree.AutoTrap na Zen Client 1.21.1 Fabric.
 *
 * Wariant: Head trap (obsydian nad głową) + Full trap (pełna klatka)
 *
 * targetBy:
 *   Closest - cel najbliżej
 *   Health  - cel z najmniejszym HP
 *
 * targetMovingPlayers - czy celować w ruszających się graczy
 */
public class AutoTrap extends Module {

    public enum TargetBy  { Closest, Health }
    public enum TrapShape { Head, Full, Feet }

    // --- Settings ---
    public final Setting<TargetBy>  targetBy            = new Setting<>("TargetBy",     TargetBy.Closest, "Jak wybierać cel");
    public final Setting<Boolean>   targetMovingPlayers = new Setting<>("TargetMoving", true,             "Celuj w ruszających się graczy");
    public final Setting<TrapShape> shape               = new Setting<>("Shape",        TrapShape.Full,   "Kształt klatki");
    public final Setting<Integer>   range               = new Setting<>("Range",        4,                "Zasięg do celu");
    public final Setting<Integer>   placeDelay          = new Setting<>("PlaceDelay",   2,                "Delay między blokami (ticki)");
    public final Setting<Boolean>   rotate              = new Setting<>("Rotate",       true,             "Obracaj się do bloków");

    // --- State ---
    private ClientPlayerEntity currentTarget = null;
    private final List<BlockPos> trapPositions = new ArrayList<>();
    private int delayCounter = 0;
    private int savedSlot    = -1;

    public AutoTrap() {
        super("AutoTrap", "Otacza cel klatką z obsydianu", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        currentTarget = null;
        trapPositions.clear();
    }

    @Override
    public void onDisable() {
        trapPositions.clear();
        restoreSlot();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        // Wybierz cel
        currentTarget = getTarget();
        if (currentTarget == null) return;

        // Sprawdź czy cel się rusza (jeśli opcja włączona)
        if (!targetMovingPlayers.getValue()) {
            Vec3d vel = currentTarget.getVelocity();
            if (Math.abs(vel.x) > 0.05 || Math.abs(vel.z) > 0.05) return;
        }

        // Znajdź obsydian w hotbarze
        int obsSlot = findObsidianSlot();
        if (obsSlot == -1) return;

        // Wygeneruj pozycje klatki
        trapPositions.clear();
        buildTrapPositions(currentTarget);
        trapPositions.removeIf(pos -> !isPlaceable(pos) || mc.player.getPos().distanceTo(Vec3d.ofCenter(pos)) > range.getValue() + 1);

        if (trapPositions.isEmpty()) return;

        // Delay
        if (delayCounter > 0) { delayCounter--; return; }

        // Przełącz slot
        savedSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = obsSlot;

        // Postaw pierwszy blok z listy
        BlockPos target = trapPositions.get(0);
        if (rotate.getValue()) rotateTo(target);
        placeAt(target);
        delayCounter = placeDelay.getValue();

        restoreSlot();
    }

    private void buildTrapPositions(ClientPlayerEntity target) {
        BlockPos base = target.getBlockPos();

        switch (shape.getValue()) {
            case Head -> {
                trapPositions.add(base.up(2)); // nad głową
            }
            case Feet -> {
                for (Direction dir : Direction.Type.HORIZONTAL)
                    trapPositions.add(base.offset(dir));
            }
            case Full -> {
                // Górna warstwa (nad głową)
                trapPositions.add(base.up(2));
                // Poziom głowy - boki
                for (Direction dir : Direction.Type.HORIZONTAL)
                    trapPositions.add(base.up().offset(dir));
                // Poziom nóg - boki
                for (Direction dir : Direction.Type.HORIZONTAL)
                    trapPositions.add(base.offset(dir));
            }
        }
    }

    private ClientPlayerEntity getTarget() {
        if (mc.world == null || mc.player == null) return null;

        return mc.world.getPlayers().stream()
            .filter(p -> p != mc.player && p.isAlive())
            .filter(p -> p.distanceTo(mc.player) <= range.getValue())
            .min((a, b) -> switch (targetBy.getValue()) {
                case Closest -> Double.compare(a.distanceTo(mc.player), b.distanceTo(mc.player));
                case Health  -> Float.compare(a.getHealth(), b.getHealth());
            })
            .orElse(null);
    }

    private void placeAt(BlockPos pos) {
        if (mc.interactionManager == null || mc.player == null) return;
        for (Direction dir : Direction.values()) {
            BlockPos neighbor = pos.offset(dir);
            if (mc.world.getBlockState(neighbor).isSolidBlock(mc.world, neighbor)) {
                BlockHitResult hit = new BlockHitResult(
                    Vec3d.ofCenter(pos), dir.getOpposite(), neighbor, false
                );
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
                return;
            }
        }
    }

    private void rotateTo(BlockPos pos) {
        if (mc.player == null) return;
        Vec3d diff = Vec3d.ofCenter(pos).subtract(mc.player.getEyePos());
        double dist = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw   = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(diff.y, dist));
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
    }

    private boolean isPlaceable(BlockPos pos) {
        if (mc.world == null) return false;
        return mc.world.getBlockState(pos).isAir();
    }

    private int findObsidianSlot() {
        if (mc.player == null) return -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() == Items.OBSIDIAN) return i;
        }
        return -1;
    }

    private void restoreSlot() {
        if (savedSlot != -1 && mc.player != null) {
            mc.player.getInventory().selectedSlot = savedSlot;
            savedSlot = -1;
        }
    }

    public ClientPlayerEntity getCurrentTarget() { return currentTarget; }
}
