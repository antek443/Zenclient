package com.zenclient.modules.movement;
import com.zenclient.modules.Module;
public class Sneak extends Module {
    public Sneak() { super("Sneak", "Sneak module", Category.MOVEMENT); }
}
