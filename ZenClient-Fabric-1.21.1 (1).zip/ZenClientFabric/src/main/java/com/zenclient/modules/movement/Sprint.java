package com.zenclient.modules.movement;
import com.zenclient.modules.Module;
public class Sprint extends Module {
    public Sprint() { super("Sprint", "Sprint module", Category.MOVEMENT); }
}
