package com.zenclient.modules.combat;
import com.zenclient.modules.Module;
public class HitboxExpand extends Module {
    public HitboxExpand() { super("HitboxExpand", "HitboxExpand module", Category.COMBAT); }
}
