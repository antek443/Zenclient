package com.zenclient.modules.movement;
import com.zenclient.modules.Module;
public class BunnyHop extends Module {
    public BunnyHop() { super("BunnyHop", "BunnyHop module", Category.MOVEMENT); }
}
