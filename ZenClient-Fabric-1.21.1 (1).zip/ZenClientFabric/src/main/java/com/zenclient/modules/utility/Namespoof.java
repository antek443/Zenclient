package com.zenclient.modules.utility;
import com.zenclient.modules.Module;
public class Namespoof extends Module {
    public Namespoof() { super("Namespoof", "Namespoof module", Category.UTILITY); }
}
