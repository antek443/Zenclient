package com.zenclient.modules.utility;
import com.zenclient.modules.Module;
public class Disabler extends Module {
    public Disabler() { super("Disabler", "Disabler module", Category.UTILITY); }
}
