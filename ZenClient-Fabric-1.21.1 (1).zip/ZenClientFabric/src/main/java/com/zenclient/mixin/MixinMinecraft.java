package com.zenclient.mixin;

import com.zenclient.ZenClientMod;
import com.zenclient.modules.visual.FullBright;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MixinMinecraft {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        if (ZenClientMod.core == null || ZenClientMod.core.moduleManager == null) return;
        FullBright fb = (FullBright) ZenClientMod.core.moduleManager.getByName("FullBright");
        if (fb != null && fb.isEnabled()) {
            MinecraftClient mc = (MinecraftClient)(Object)this;
            mc.options.getGamma().setValue(100.0);
        }
    }
}
