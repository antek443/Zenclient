package com.zenclient.mixin;

import com.zenclient.ZenClientMod;
import com.zenclient.modules.visual.ESP;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public class MixinLivingEntityRenderer {

    @Inject(method = "isVisible", at = @At("HEAD"), cancellable = true)
    private void onIsVisible(LivingEntity entity, CallbackInfoReturnable<Boolean> cir) {
        if (ZenClientMod.core == null || ZenClientMod.core.moduleManager == null) return;
        ESP esp = (ESP) ZenClientMod.core.moduleManager.getByName("ESP");
        if (esp != null && esp.isEnabled()) cir.setReturnValue(true);
    }
}
