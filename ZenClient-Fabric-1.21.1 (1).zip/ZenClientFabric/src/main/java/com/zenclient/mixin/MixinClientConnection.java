package com.zenclient.mixin;

import com.zenclient.ZenClientMod;
import com.zenclient.modules.combat.FakeLag;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientConnection.class)
public class MixinClientConnection {

    @Inject(method = "sendImmediately", at = @At("HEAD"), cancellable = true)
    private void onSendPacket(Packet<?> packet, PacketCallbacks callbacks, CallbackInfo ci) {
        if (ZenClientMod.core == null || ZenClientMod.core.moduleManager == null) return;

        FakeLag fakeLag = (FakeLag) ZenClientMod.core.moduleManager.getByName("FakeLag");
        if (fakeLag != null && fakeLag.onPacketSend(packet)) {
            ci.cancel(); // zablokuj wysyłanie — paczka trafia do kolejki
        }
    }
}
