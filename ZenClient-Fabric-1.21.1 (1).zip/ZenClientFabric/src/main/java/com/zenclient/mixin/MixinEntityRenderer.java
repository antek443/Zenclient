package com.zenclient.mixin;

import com.zenclient.ZenClientMod;
import com.zenclient.modules.visual.ESP;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class MixinEntityRenderer {

    @Inject(method = "hasLabel(Lnet/minecraft/entity/Entity;Z)Z", at = @At("HEAD"), cancellable = true)
    private void onHasLabel(Entity entity, boolean bl, CallbackInfoReturnable<Boolean> cir) {
        if (ZenClientMod.core == null || ZenClientMod.core.moduleManager == null) return;
        ESP esp = (ESP) ZenClientMod.core.moduleManager.getByName("ESP");
        if (esp != null && esp.isEnabled()) cir.setReturnValue(true);
    }
}
