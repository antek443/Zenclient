package com.zenclient.client;

import com.zenclient.gui.ZenGUI;
import com.zenclient.modules.ModuleManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ZenClientCore {

    public static ZenClientCore INSTANCE;
    public ModuleManager moduleManager;
    public static KeyBinding KEY_OPEN_GUI;

    public void init() {
        INSTANCE = this;
        moduleManager = new ModuleManager();
        moduleManager.initModules();

        KEY_OPEN_GUI = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.zenclient.opengui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_P,
            "key.categories.zenclient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (KEY_OPEN_GUI.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ZenGUI());
                } else if (client.currentScreen instanceof ZenGUI) {
                    client.setScreen(null);
                }
            }
            if (client.player != null) {
                moduleManager.tickModules();
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickDeltaManager) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.currentScreen == null && mc.player != null) {
                moduleManager.renderHUD(drawContext);
            }
        });
    }
}
