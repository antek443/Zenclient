package com.zenclient;

import com.zenclient.client.ZenClientCore;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZenClientMod implements ClientModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("zenclient");
    public static ZenClientCore core;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[ZenClient] Loading...");
        core = new ZenClientCore();
        core.init();
        LOGGER.info("[ZenClient] Loaded! Press P to open GUI.");
    }
}
