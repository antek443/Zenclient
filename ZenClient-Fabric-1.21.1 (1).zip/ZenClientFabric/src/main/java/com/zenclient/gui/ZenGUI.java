package com.zenclient.gui;

import com.zenclient.ZenClientMod;
import com.zenclient.modules.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public class ZenGUI extends Screen {

    // Panel
    private static final int PW = 800, PH = 500;
    private static final int SW = 160; // sidebar width
    private static final int HH = 44;  // header height

    // Colors
    private static final int BG     = 0xFF0E0E16;
    private static final int SB     = 0xFF0A0A12;
    private static final int HDR    = 0xFF08080F;
    private static final int CARD   = 0xFF181825;
    private static final int CARDA  = 0xFF1E1E35;
    private static final int CARDH  = 0xFF1A1A2A;
    private static final int ACC    = 0xFF7B6FFF;
    private static final int WHITE  = 0xFFEEEEFF;
    private static final int GRAY   = 0xFF9090AA;
    private static final int DGRAY  = 0xFF4A4A60;
    private static final int SEP    = 0xFF1E1E30;

    private int px, py;
    private Module.Category cat = Module.Category.COMBAT;
    private int scroll = 0, maxScroll = 0;
    private boolean drag = false;
    private int dx, dy;

    public ZenGUI() {
        super(Text.literal("ZenClient"));
    }

    @Override
    protected void init() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;
        scroll = 0;
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext c, int mx, int my, float dt) {
        // Darken background
        c.fill(0, 0, width, height, 0xAA000000);

        // Main panel
        c.fill(px, py, px+PW, py+PH, BG);

        // Sidebar
        c.fill(px, py, px+SW, py+PH, SB);

        // Header
        c.fill(px, py, px+PW, py+HH, HDR);
        c.fill(px, py+HH, px+PW, py+HH+1, SEP);
        c.fill(px+SW, py, px+SW+1, py+PH, SEP);

        // Logo w headerze
        c.drawText(textRenderer, "§7Zen§fClient", px+10, py+8, WHITE, false);
        c.drawText(textRenderer, "§8v1.0 | 1.21.1", px+10, py+20, DGRAY, false);

        // Aktywne moduły count
        int en = ZenClientMod.core.moduleManager.getEnabledModules().size();
        String enStr = en + " active";
        c.drawText(textRenderer, enStr, px+PW-textRenderer.getWidth(enStr)-8, py+16, ACC, false);

        // Klawisz [P] info
        c.drawText(textRenderer, "[P] close", px+PW-80, py+HH-12, DGRAY, false);

        // === Sidebar: kategorie ===
        int ty = py + HH + 8;
        for (Module.Category ct : Module.Category.values()) {
            boolean sel = ct == cat;
            boolean hov = mx >= px && mx < px+SW && my >= ty && my < ty+28;

            if (sel) {
                c.fill(px, ty, px+SW, ty+28, CARDA);
                c.fill(px, ty, px+3, ty+28, ACC);
            } else if (hov) {
                c.fill(px, ty, px+SW, ty+28, CARDH);
            }

            int tc = sel ? WHITE : GRAY;
            c.drawText(textRenderer, ct.icon + " " + ct.label, px+12, ty+10, tc, false);

            // badge
            long enCat = ZenClientMod.core.moduleManager.getByCategory(ct)
                .stream().filter(Module::isEnabled).count();
            if (enCat > 0) {
                String b = String.valueOf(enCat);
                c.fill(px+SW-22, ty+7, px+SW-4, ty+21, ACC);
                c.drawText(textRenderer, b, px+SW-22+(14-textRenderer.getWidth(b))/2, ty+10, WHITE, false);
            }

            ty += 30;
        }

        // === Moduły: grid 2 kolumny ===
        List<Module> mods = ZenClientMod.core.moduleManager.getByCategory(cat);
        int contentX = px + SW + 8;
        int contentY = py + HH + 8;
        int contentW = PW - SW - 16;
        int contentH = PH - HH - 8;
        int cols = 2;
        int cardW = (contentW - 8) / cols;
        int cardH = 48;
        int gap = 6;

        int rows = (mods.size() + cols - 1) / cols;
        maxScroll = Math.max(0, rows * (cardH + gap) - contentH + 8);
        if (scroll > maxScroll) scroll = maxScroll;

        // Clip area (prevent drawing outside)
        int ci = 0;
        for (Module mod : mods) {
            int col = ci % cols;
            int row = ci / cols;
            int cx = contentX + col * (cardW + 8);
            int cy = contentY + row * (cardH + gap) - scroll;

            // Skip out of bounds
            if (cy + cardH < contentY || cy > contentY + contentH) { ci++; continue; }

            boolean on  = mod.isEnabled();
            boolean hov = mx >= cx && mx < cx+cardW && my >= cy && my < cy+cardH;

            // Card background
            int cardColor = on ? CARDA : hov ? CARDH : CARD;
            c.fill(cx, cy, cx+cardW, cy+cardH, cardColor);

            // Left bar gdy włączony
            if (on) c.fill(cx, cy, cx+3, cy+cardH, ACC);

            // Outline hover
            if (hov && !on) {
                c.fill(cx, cy, cx+cardW, cy+1, SEP);
                c.fill(cx, cy+cardH-1, cx+cardW, cy+cardH, SEP);
            }

            // Nazwa modułu
            c.drawText(textRenderer, mod.getName(), cx+10, cy+10, on ? WHITE : GRAY, false);

            // Opis
            String desc = mod.getDescription();
            if (desc.length() > 28) desc = desc.substring(0, 26) + "..";
            c.drawText(textRenderer, desc, cx+10, cy+24, DGRAY, false);

            // Toggle pill
            int pw2 = 26, ph2 = 12;
            int pillX = cx + cardW - pw2 - 8;
            int pillY = cy + (cardH - ph2) / 2;
            c.fill(pillX, pillY, pillX+pw2, pillY+ph2, on ? ACC : 0xFF252535);
            // Kółko
            int dotX = on ? pillX+pw2-12 : pillX+2;
            c.fill(dotX, pillY+2, dotX+8, pillY+10, on ? WHITE : DGRAY);

            ci++;
        }

        // Scrollbar
        if (maxScroll > 0) {
            int sbX = px + PW - 5;
            int sbY = contentY;
            int sbH = contentH;
            c.fill(sbX, sbY, sbX+3, sbY+sbH, 0xFF111120);
            int th = Math.max(20, sbH * sbH / (sbH + maxScroll));
            int tY = sbY + (int)((float)scroll / maxScroll * (sbH - th));
            c.fill(sbX, tY, sbX+3, tY+th, ACC);
        }

        // Border
        c.fill(px, py, px+PW, py+1, ACC);
        c.fill(px, py+PH-1, px+PW, py+PH, SEP);
        c.fill(px, py, px+1, py+PH, SEP);
        c.fill(px+PW-1, py, px+PW, py+PH, SEP);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        // Drag przez header
        if (mx >= px && mx < px+PW && my >= py && my < py+HH) {
            drag=true; dx=(int)mx-px; dy=(int)my-py; return true;
        }

        // Kategoria
        int ty = py + HH + 8;
        for (Module.Category ct : Module.Category.values()) {
            if (mx >= px && mx < px+SW && my >= ty && my < ty+28) {
                cat = ct; scroll = 0; return true;
            }
            ty += 30;
        }

        // Moduł toggle
        List<Module> mods = ZenClientMod.core.moduleManager.getByCategory(cat);
        int contentX = px+SW+8, contentY = py+HH+8;
        int contentW = PW-SW-16;
        int cols = 2, cardW = (contentW-8)/cols, cardH = 48, gap = 6;

        for (int i = 0; i < mods.size(); i++) {
            int col = i%cols, row = i/cols;
            int cx = contentX + col*(cardW+8);
            int cy = contentY + row*(cardH+gap) - scroll;
            if (mx>=cx && mx<cx+cardW && my>=cy && my<cy+cardH) {
                mods.get(i).toggle(); return true;
            }
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double ddx, double ddy) {
        if (drag) {
            px = Math.max(0, Math.min((int)mx-dx, width-PW));
            py = Math.max(0, Math.min((int)my-dy, height-PH));
        }
        return super.mouseDragged(mx, my, btn, ddx, ddy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) { drag=false; return super.mouseReleased(mx,my,btn); }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = Math.max(0, Math.min(maxScroll, scroll - (int)(v*12)));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 80 || key == 256) { // P lub Escape
            this.client.setScreen(null);
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }
}
